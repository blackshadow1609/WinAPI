﻿=== Starcraft Small Version Cursor Set ===

By: Cursor Mania (http://www.rw-designer.com/user/111242)

Download: http://www.rw-designer.com/cursor-set/starcraft-small-version

Author's description:

The small verion of this awesome cursor set, I'm in proccess to do much more cursor thanks to the awesome people that stayed with me since my first cursor set.
Thanks to all of you!!

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.